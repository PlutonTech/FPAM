// ── ASSET REGISTRY ──────────────────────────────────────────────────────────
let filteredAssets = [];
let selectedAssetIds = new Set();

async function renderAssets() {
  try {
    const q = document.getElementById('search-input')?.value.trim() || '';
    const type = document.getElementById('filter-type')?.value || '';
    const cond = document.getElementById('filter-cond')?.value || '';
    const geom = document.getElementById('filter-geom')?.value || '';
    const params = {};
    if (type) params.type = type;
    if (cond) params.condition = cond;
    const r = await apiGetAssets(params);
    filteredAssets = r.assets || [];
    if (q) filteredAssets = filteredAssets.filter(a =>
      (a.name||'').toLowerCase().includes(q.toLowerCase()) ||
      (a.assetId||'').toLowerCase().includes(q.toLowerCase()) ||
      (a.state||'').toLowerCase().includes(q.toLowerCase())
    );
    if (geom) filteredAssets = filteredAssets.filter(a => (a.geomType||a.geom) === geom);
  } catch {
    // Offline fallback
    filteredAssets = [...assets];
    const q = document.getElementById('search-input')?.value.trim().toLowerCase() || '';
    const type = document.getElementById('filter-type')?.value || '';
    const cond = document.getElementById('filter-cond')?.value || '';
    const geom = document.getElementById('filter-geom')?.value || '';
    if (q) filteredAssets = filteredAssets.filter(a =>
      (a.name||'').toLowerCase().includes(q) || (a.id||'').toLowerCase().includes(q) ||
      (a.state||'').toLowerCase().includes(q)
    );
    if (type) filteredAssets = filteredAssets.filter(a => a.type === type);
    if (cond) filteredAssets = filteredAssets.filter(a => a.condition === cond);
    if (geom) filteredAssets = filteredAssets.filter(a => (a.geomType||a.geom) === geom);
  }
  renderAssetsTable(filteredAssets);
}

function renderAssetsTable(list) {
  const tbody = document.getElementById('assets-tbody');
  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="10"><div class="empty-state">
      <div class="empty-icon"><i class="fa-solid fa-layer-group"></i></div>
      <div class="empty-title">No assets found</div>
      <div class="empty-sub">Adjust filters or capture a new asset</div>
    </div></td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(a => {
    const id = a.assetId || a.id;
    const geom = a.geomType || a.geom || '—';
    const lat = a.lat || a.location?.coordinates?.[1] || '—';
    const lng = a.lng || a.location?.coordinates?.[0] || '—';
    const agent = a.agent || a.capturedBy?.name || '—';
    return `<tr>
      <td style="width:36px"><input type="checkbox" class="asset-row-check" data-id="${id}" onchange="onAssetRowCheck()" ${selectedAssetIds.has(id)?'checked':''}></td>
      <td style="font-family:'Space Mono',monospace;font-size:10px;color:var(--text3)">${escHtml(id)}</td>
      <td><strong>${escHtml(a.name)}</strong></td>
      <td><span class="tag ${typeColor(a.type)}">${escHtml(a.type)}</span></td>
      <td>${geomIcon(geom)} <span style="font-size:11px;color:var(--text3);margin-left:2px">${geom}</span></td>
      <td><span class="tag ${condColor(a.condition)}">${escHtml(a.condition)}</span></td>
      <td style="font-family:'Space Mono',monospace;font-size:10px;color:var(--text3)">${typeof lat==='number'?lat.toFixed(4):lat}, ${typeof lng==='number'?lng.toFixed(4):lng}</td>
      <td style="font-size:12px;color:var(--text2)">${escHtml(a.state||'—')}</td>
      <td>${typeof calcRiskScore !== 'undefined' ? riskBadge(calcRiskScore(a)) : ''}</td>
      <td style="font-size:12px;color:var(--text3)">${escHtml(agent)}</td>
      <td>
        <div style="display:flex;gap:6px">
          <button class="btn btn-ghost btn-xs" onclick='showAssetDetail(${JSON.stringify(a).replace(/'/g,"&#39;")})' title="View detail">
            <i class="fa-solid fa-eye"></i>
          </button>
          <button class="btn btn-ghost btn-xs" onclick='openEditAsset(${JSON.stringify(a).replace(/'/g,"&#39;")})' title="Edit">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <button class="btn btn-danger btn-xs" onclick="deleteAsset('${id}')" title="Delete">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function filterAssets() { renderAssets(); }
function clearFilters() {
  ['search-input','filter-type','filter-cond','filter-geom'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  renderAssets();
}

// ── ASSET DETAIL ──────────────────────────────────────────────────────────────
// showAssetDetail and switchDetailTab are defined in asset_detail.js (loaded
// before this file). Do not redefine them here — asset_detail.js is canonical.

function openAddMaintenance(assetId) {
  openModal('Add Maintenance Log',
    `<div class="form-grid">
      <div class="form-group full"><label class="form-label">Description *</label><input class="form-control" id="maint-desc" placeholder="e.g. Routine inspection completed"></div>
      <div class="form-group"><label class="form-label">Date *</label><input class="form-control" id="maint-date" type="date" value="${new Date().toISOString().split('T')[0]}"></div>
      <div class="form-group"><label class="form-label">Technician</label><input class="form-control" id="maint-tech" placeholder="Name"></div>
      <div class="form-group"><label class="form-label">Cost (NGN)</label><input class="form-control" id="maint-cost" type="number" placeholder="0"></div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary" onclick="saveMaintenance('${assetId}')"><i class="fa-solid fa-save"></i> Save</button>`
  );
}

async function saveMaintenance(assetId) {
  const desc = document.getElementById('maint-desc')?.value.trim();
  const date = document.getElementById('maint-date')?.value;
  if (!desc || !date) { toast('Description and date required', 'fa-triangle-exclamation', true); return; }
  const data = { desc, date, tech: document.getElementById('maint-tech')?.value, cost: parseFloat(document.getElementById('maint-cost')?.value) || 0 };
  try {
    await apiAddMaintenance(assetId, data);
    toast('Maintenance log added', 'fa-circle-check');
  } catch {
    const a = assets.find(x => (x.assetId||x.id) === assetId);
    if (a) { a.maintenanceLogs = a.maintenanceLogs || []; a.maintenanceLogs.push(data); saveLocal(); }
    toast('Saved locally', 'fa-circle-check');
  }
  closeModal();
  addAudit('MAINTENANCE_LOGGED', assetId, null, desc);
}

// ── DELETE ────────────────────────────────────────────────────────────────────
async function deleteAsset(id) {
  if (!confirm(`Delete asset ${id}? This cannot be undone.`)) return;
  try {
    await apiDeleteAsset(id);
    toast('Asset deleted', 'fa-trash');
  } catch {
    assets = assets.filter(a => (a.assetId||a.id) !== id);
    saveLocal();
    toast('Deleted locally', 'fa-trash');
  }
  addAudit('ASSET_DELETED', id, null, 'Asset removed');
  renderAssets();
  renderDashboard();
}

// ── EDIT ──────────────────────────────────────────────────────────────────────
function openEditAsset(a) {
  const id = a.assetId || a.id;
  openModal('Edit Asset',
    `<div class="form-grid">
      <div class="form-group full"><label class="form-label">Name</label><input class="form-control" id="edit-name" value="${escHtml(a.name)}"></div>
      <div class="form-group"><label class="form-label">Condition</label>
        <select class="form-control" id="edit-cond">
          ${['Good','Fair','Poor','Critical'].map(c=>`<option ${a.condition===c?'selected':''}>${c}</option>`).join('')}
        </select></div>
      <div class="form-group"><label class="form-label">Status</label>
        <select class="form-control" id="edit-status">
          ${['Active','Under Maintenance','Decommissioned','Disputed','Recovered'].map(s=>`<option ${(a.status||'Active')===s?'selected':''}>${s}</option>`).join('')}
        </select></div>
      <div class="form-group"><label class="form-label">State</label><input class="form-control" id="edit-state" value="${escHtml(a.state||'')}"></div>
      <div class="form-group"><label class="form-label">LGA</label><input class="form-control" id="edit-lga" value="${escHtml(a.lga||'')}"></div>
      <div class="form-group full"><label class="form-label">Notes</label><textarea class="form-control" id="edit-notes">${escHtml(a.notes||'')}</textarea></div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
     <button class="btn btn-primary" onclick="saveEditedAsset('${id}')"><i class="fa-solid fa-save"></i> Save Changes</button>`
  );
}

async function saveEditedAsset(id) {
  const data = {
    name:      document.getElementById('edit-name')?.value.trim(),
    condition: document.getElementById('edit-cond')?.value,
    status:    document.getElementById('edit-status')?.value,
    state:     document.getElementById('edit-state')?.value,
    lga:       document.getElementById('edit-lga')?.value,
    notes:     document.getElementById('edit-notes')?.value,
  };
  try {
    await apiUpdateAsset(id, data);
    toast('Asset updated', 'fa-circle-check');
  } catch {
    const a = assets.find(x => (x.assetId||x.id) === id);
    if (a) Object.assign(a, data);
    saveLocal();
    toast('Saved locally', 'fa-circle-check');
  }
  addAudit('ASSET_UPDATED', id, null, `${data.name} updated`);
  closeModal();
  renderAssets();
}

// ── BULK ACTIONS ──────────────────────────────────────────────────────────────
function onAssetRowCheck() {
  selectedAssetIds = new Set([...document.querySelectorAll('.asset-row-check:checked')].map(c => c.dataset.id));
  updateBulkBar();
}
function toggleSelectAllAssets(checked) {
  document.querySelectorAll('.asset-row-check').forEach(c => { c.checked = checked; });
  selectedAssetIds = checked ? new Set([...document.querySelectorAll('.asset-row-check')].map(c => c.dataset.id)) : new Set();
  updateBulkBar();
}
function updateBulkBar() {
  const n = selectedAssetIds.size;
  const bar = document.getElementById('bulk-action-bar');
  const toolbar = document.getElementById('asset-selection-toolbar');
  const countEl = document.getElementById('sel-toolbar-count');
  if (countEl) countEl.textContent = n + ' selected';
  if (toolbar) toolbar.style.display = n > 0 ? 'flex' : 'none';
  if (bar) bar.classList.toggle('visible', n > 0);
  const bulkCount = document.getElementById('bulk-count');
  if (bulkCount) bulkCount.textContent = n + ' selected';
}
function clearBulkSelection() {
  selectedAssetIds.clear();
  document.querySelectorAll('.asset-row-check').forEach(c => c.checked = false);
  updateBulkBar();
}

async function bulkDelete() {
  if (!selectedAssetIds.size) return;
  if (!confirm(`Delete ${selectedAssetIds.size} assets? This cannot be undone.`)) return;
  for (const id of selectedAssetIds) {
    try { await apiDeleteAsset(id); } catch { assets = assets.filter(a => (a.assetId||a.id) !== id); }
  }
  saveLocal();
  addAudit('BULK_DELETE', 'MULTIPLE', null, `${selectedAssetIds.size} assets deleted`);
  selectedAssetIds.clear();
  updateBulkBar();
  renderAssets();
  toast(`${selectedAssetIds.size || 'Selected'} assets deleted`, 'fa-trash');
}

function bulkExportCSV() {
  downloadExport('csv', [...selectedAssetIds]);
}

// ── PAGE-LEVEL ENTRY POINTS ───────────────────────────────────────────────────

// Entry point called by assets.html DOMContentLoaded
const loadAssets = renderAssets;

// Column sort — called by table header onclick="sortBy('field')"
let _sortField = 'ts';
let _sortDir   = -1;

function sortBy(field) {
  if (_sortField === field) { _sortDir *= -1; } else { _sortField = field; _sortDir = -1; }
  filteredAssets.sort((a, b) => {
    const va = a[field] || a.location?.coordinates?.[field] || '';
    const vb = b[field] || b.location?.coordinates?.[field] || '';
    if (typeof va === 'number') return (va - vb) * _sortDir;
    return String(va).localeCompare(String(vb)) * _sortDir;
  });
  renderAssetsTable(filteredAssets);
}

// Toolbar handlers — thin wrappers so HTML onclick strings stay short
function exportAssets(fmt)        { downloadExport(fmt); }
function toggleSelectAll(checked) { toggleSelectAllAssets(checked); }
function clearSelection()         { clearBulkSelection(); }
function bulkExport(fmt)          { downloadExport(fmt, [...selectedAssetIds]); }
