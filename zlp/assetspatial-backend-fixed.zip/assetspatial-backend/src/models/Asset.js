'use strict';
const mongoose = require('mongoose');
const { Schema, Types } = mongoose;

const fileRefSchema = new Schema({
  fileId:     { type: Types.ObjectId, required: true },
  filename:   String,
  mimeType:   String,
  sizeBytes:  Number,
  capturedAt: Date,
  uploadedAt: { type: Date, default: Date.now },
}, { _id: false });

const maintenanceLogSchema = new Schema({
  date:     { type: Date, required: true },
  desc:     { type: String, required: true },
  tech:     String,
  cost:     { type: Number, min: 0 },   // NGN
  loggedBy: { type: Types.ObjectId, ref: 'User' },
}, { _id: true, timestamps: false });

const assetSchema = new Schema({
  assetId: { type: String, required: true, unique: true, index: true },
  name:    { type: String, required: true, trim: true },

  type: {
    type: String,
    required: true,
    enum: ['Infrastructure', 'Land / Property', 'Utility', 'Environmental', 'Equipment'],
  },
  geomType: {
    type: String,
    enum: ['Point', 'Polygon', 'Linear'],
    default: 'Point',
  },

  // GeoJSON Point — enables $near, $geoWithin, $geoIntersects
  location: {
    type:        { type: String, default: 'Point', enum: ['Point'] },
    coordinates: { type: [Number], required: true },  // [lng, lat]
  },

  // Full GeoJSON geometry for polygons/linestrings
  geometry: { type: Schema.Types.Mixed },

  condition: { type: String, enum: ['Good', 'Fair', 'Poor', 'Critical'] },
  material:  String,
  elevation: Number,
  area:      Number,  // sqm — computed server-side via Turf.js
  notes:     String,

  // Type-specific fields validated per type via Joi in routes
  typeData: { type: Schema.Types.Mixed, default: {} },

  // References
  capturedBy: { type: Types.ObjectId, ref: 'User' },
  mda:        String,   // Ministry / Department / Agency
  state:      String,
  lga:        String,
  address:    String,

  status: {
    type: String,
    enum: ['Active', 'Under Maintenance', 'Decommissioned', 'Disputed', 'Recovered'],
    default: 'Active',
  },

  // File attachments (stored in GridFS, referenced here)
  photos:    [fileRefSchema],
  documents: [fileRefSchema],
  xlDatasets: [{
    fileId:    Types.ObjectId,
    filename:  String,
    rowCount:  Number,
    columns:   [String],
    uploadedAt: { type: Date, default: Date.now },
  }],

  maintenanceLogs: [maintenanceLogSchema],

  valuation: {
    amount:   Number,
    currency: { type: String, default: 'NGN' },
    valuedAt: Date,
    method:   { type: String, enum: ['Replacement Cost', 'Market Comparable', 'Depreciated'] },
  },

  qrPayload: String,

  ocrSource: {
    filename:  String,
    engine:    { type: String, enum: ['tesseract', 'manual'] },
    rawText:   String,
    scannedAt: Date,
  },

  captureDate: { type: Date, default: Date.now },
}, {
  timestamps: true,  // adds createdAt + updatedAt
  toJSON:     { virtuals: true },
});

// ── Indexes ──────────────────────────────────────────────────────────────────
assetSchema.index({ location: '2dsphere' });
assetSchema.index({ type: 1, condition: 1 });
assetSchema.index({ state: 1, lga: 1 });
assetSchema.index({ capturedBy: 1 });
assetSchema.index({ status: 1 });
assetSchema.index({ captureDate: -1 });
assetSchema.index({ 'maintenanceLogs.date': 1 });
assetSchema.index({ name: 'text', notes: 'text', address: 'text' });

module.exports = mongoose.model('Asset', assetSchema);
