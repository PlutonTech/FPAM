'use strict';
const Asset = require('../models/Asset');
const turf = require('@turf/turf');

/**
 * Generate sequential asset ID like "AST-1042"
 */
async function nextAssetId() {
  const last = await Asset.findOne({}, { assetId: 1 }).sort({ createdAt: -1 }).lean();
  if (!last || !last.assetId) return 'AST-1001';
  const num = parseInt(last.assetId.replace('AST-', ''), 10);
  return `AST-${num + 1}`;
}

/**
 * Compute and attach area/length for polygon/linear assets.
 */
function computeSpatial(data) {
  if (data.geomType === 'Polygon' && data.geometry) {
    try {
      const poly = turf.polygon(data.geometry.coordinates || [data.geometry]);
      data.area = Math.round(turf.area(poly));
    } catch (_) { /* non-fatal */ }
  }
  if (data.geomType === 'Linear' && data.geometry) {
    try {
      const line = turf.lineString(data.geometry.coordinates || [data.geometry]);
      data.area = Math.round(turf.length(line, { units: 'meters' }));
    } catch (_) { /* non-fatal */ }
  }
  return data;
}

async function createAsset(body, userId) {
  const assetId = await nextAssetId();
  const data = computeSpatial({
    ...body,
    assetId,
    capturedBy: userId,
    location: {
      type: 'Point',
      coordinates: body.coordinates,   // [lng, lat]
    },
  });
  delete data.coordinates;
  return Asset.create(data);
}

async function listAssets({ type, condition, state, lga, geomType, status, page = 1, limit = 50, scopeFilter = {} }) {
  const filter = { ...scopeFilter };
  if (type)      filter.type = type;
  if (condition) filter.condition = condition;
  if (state)     filter.state = state;
  if (lga)       filter.lga = lga;
  if (geomType)  filter.geomType = geomType;
  if (status)    filter.status = status;

  const skip = (page - 1) * limit;
  const [assets, total] = await Promise.all([
    Asset.find(filter).skip(skip).limit(limit).sort({ createdAt: -1 }).lean(),
    Asset.countDocuments(filter),
  ]);

  return { assets, total, page: +page, pages: Math.ceil(total / limit) };
}

async function getAsset(id) {
  // Accept both Mongo _id and assetId ("AST-xxxx")
  const query = id.startsWith('AST-') ? { assetId: id } : { _id: id };
  return Asset.findOne(query).populate('capturedBy', 'name email role').lean();
}

async function updateAsset(id, body) {
  const query = id.startsWith('AST-') ? { assetId: id } : { _id: id };
  const data = computeSpatial({ ...body });
  if (body.coordinates) {
    data.location = { type: 'Point', coordinates: body.coordinates };
    delete data.coordinates;
  }
  return Asset.findOneAndUpdate(query, { $set: data }, { new: true, runValidators: true }).lean();
}

async function deleteAsset(id) {
  const query = id.startsWith('AST-') ? { assetId: id } : { _id: id };
  return Asset.findOneAndDelete(query).lean();
}

async function searchAssets(q, scopeFilter = {}) {
  return Asset.find({
    $text: { $search: q },
    ...scopeFilter,
  }, { score: { $meta: 'textScore' } })
    .sort({ score: { $meta: 'textScore' } })
    .limit(100)
    .lean();
}

module.exports = { createAsset, listAssets, getAsset, updateAsset, deleteAsset, searchAssets };
