'use strict';
const router = require('express').Router();
const { authenticate }     = require('../middleware/auth');
const { resolvePermissions, requirePerm } = require('../middleware/resolvePermissions');
const { scopeFilter }      = require('../middleware/scopeFilter');
const { auditLog }         = require('../middleware/auditMiddleware');
const { validateBody, schemas } = require('../middleware/validate');
const assetSvc  = require('../services/assetService');
const { emitNewAsset } = require('../sockets/realtime');

const auth = [authenticate, resolvePermissions, scopeFilter];

// GET /api/assets
router.get('/', ...auth, async (req, res, next) => {
  try {
    const result = await assetSvc.listAssets({ ...req.query, scopeFilter: req.scopeFilter });
    res.json(result);
  } catch (err) { next(err); }
});

// GET /api/assets/search
router.get('/search', ...auth, async (req, res, next) => {
  try {
    const q = req.query.q;
    if (!q) return res.status(400).json({ error: 'Query parameter q is required' });
    const assets = await assetSvc.searchAssets(q, req.scopeFilter);
    res.json({ assets });
  } catch (err) { next(err); }
});

// POST /api/assets
router.post('/',
  ...auth,
  requirePerm('canCreateAssets'),
  validateBody(schemas.asset),
  auditLog('ASSET_CREATED', 'Asset'),
  async (req, res, next) => {
    try {
      const asset = await assetSvc.createAsset(req.body, req.user._id);
      res.locals.auditEntityId = asset.assetId;
      res.locals.auditDetail   = `${asset.name} captured`;
      emitNewAsset(asset);
      res.status(201).json({ asset });
    } catch (err) { next(err); }
  }
);

// GET /api/assets/:id
router.get('/:id', ...auth, async (req, res, next) => {
  try {
    const asset = await assetSvc.getAsset(req.params.id);
    if (!asset) return res.status(404).json({ error: 'Asset not found' });
    res.json({ asset });
  } catch (err) { next(err); }
});

// PUT /api/assets/:id
router.put('/:id',
  ...auth,
  requirePerm('canEditAssets'),
  validateBody(schemas.asset),
  auditLog('ASSET_UPDATED', 'Asset'),
  async (req, res, next) => {
    try {
      const asset = await assetSvc.updateAsset(req.params.id, req.body);
      if (!asset) return res.status(404).json({ error: 'Asset not found' });
      res.locals.auditDetail = `${asset.name} updated`;
      res.json({ asset });
    } catch (err) { next(err); }
  }
);

// DELETE /api/assets/:id
router.delete('/:id',
  ...auth,
  requirePerm('canDeleteAssets'),
  auditLog('ASSET_DELETED', 'Asset'),
  async (req, res, next) => {
    try {
      const asset = await assetSvc.deleteAsset(req.params.id);
      if (!asset) return res.status(404).json({ error: 'Asset not found' });
      res.locals.auditDetail = `${asset.name} deleted`;
      res.json({ message: 'Asset deleted' });
    } catch (err) { next(err); }
  }
);

// POST /api/assets/:id/maintenance
router.post('/:id/maintenance',
  ...auth,
  validateBody(schemas.maintenanceLog),
  auditLog('MAINTENANCE_LOGGED', 'Asset'),
  async (req, res, next) => {
    try {
      const { id } = req.params;
      const query  = id.startsWith('AST-') ? { assetId: id } : { _id: id };
      const Asset  = require('../models/Asset');
      const log    = { ...req.body, loggedBy: req.user._id };
      const asset  = await Asset.findOneAndUpdate(
        query,
        { $push: { maintenanceLogs: log } },
        { new: true }
      ).lean();
      if (!asset) return res.status(404).json({ error: 'Asset not found' });
      res.locals.auditDetail = `Maintenance logged for ${asset.name}`;
      res.status(201).json({ asset });
    } catch (err) { next(err); }
  }
);

// DELETE /api/assets/:id/maintenance/:idx
router.delete('/:id/maintenance/:idx', ...auth, requirePerm('canEditAssets'),
  auditLog('MAINTENANCE_DELETED', 'Asset'),
  async (req, res, next) => {
    try {
      const Asset = require('../models/Asset');
      const query = req.params.id.startsWith('AST-') ? { assetId: req.params.id } : { _id: req.params.id };
      const asset = await Asset.findOne(query);
      if (!asset) return res.status(404).json({ error: 'Asset not found' });
      asset.maintenanceLogs.splice(+req.params.idx, 1);
      await asset.save();
      res.json({ asset: asset.toObject() });
    } catch (err) { next(err); }
  }
);

// PUT /api/assets/:id/valuation
router.put('/:id/valuation',
  ...auth,
  requirePerm('canEditAssets'),
  validateBody(schemas.valuation),
  auditLog('VALUATION_UPDATED', 'Asset'),
  async (req, res, next) => {
    try {
      const Asset = require('../models/Asset');
      const query = req.params.id.startsWith('AST-') ? { assetId: req.params.id } : { _id: req.params.id };
      const asset = await Asset.findOneAndUpdate(
        query,
        { $set: { valuation: req.body } },
        { new: true }
      ).lean();
      if (!asset) return res.status(404).json({ error: 'Asset not found' });
      res.json({ asset });
    } catch (err) { next(err); }
  }
);

module.exports = router;
