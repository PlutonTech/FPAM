'use strict';
const RoleConfig = require('../models/RoleConfig');

/**
 * Merges role-level defaults with per-user permission overrides.
 * Attaches result to req.effectivePermissions.
 * Must run AFTER authenticate().
 */
async function resolvePermissions(req, res, next) {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    // System Admins always have full access — skip DB lookup
    if (user.role === 'System Admin') {
      req.effectivePermissions = { all: true };
      return next();
    }

    const roleConfig = await RoleConfig.findOne({ role: user.role }).lean();
    const defaults = roleConfig?.defaults || {};

    // User-level overrides win; only override keys that are explicitly set (not undefined)
    const overrides = {};
    if (user.permissions) {
      for (const [k, v] of Object.entries(user.permissions)) {
        if (v !== undefined && v !== null) overrides[k] = v;
      }
    }

    req.effectivePermissions = { ...defaults, ...overrides };
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Convenience — guard a single permission key.
 * Usage: router.post('/assets', auth, resolvePermissions, requirePerm('canCreateAssets'), handler)
 */
function requirePerm(key) {
  return (req, res, next) => {
    const perms = req.effectivePermissions;
    if (!perms) return res.status(403).json({ error: 'Permissions not resolved' });
    if (perms.all || perms[key]) return next();
    return res.status(403).json({ error: `Permission denied: ${key}` });
  };
}

module.exports = { resolvePermissions, requirePerm };
