'use strict';

/**
 * Builds a MongoDB query filter reflecting the user's geographic scope.
 * Attaches req.scopeFilter — apply this to all asset queries.
 */
function scopeFilter(req, res, next) {
  const { role, states, lgas } = req.user;

  // Unrestricted roles see everything
  if (role === 'System Admin' || role === 'GIS Analyst') {
    req.scopeFilter = {};
    return next();
  }

  // Supervisor and Field Agent are scoped to assigned states
  if (!states || states.length === 0) {
    // No states assigned — they see nothing (safety default)
    req.scopeFilter = { state: { $in: [] } };
    return next();
  }

  req.scopeFilter = { state: { $in: states } };

  if (lgas && lgas.length > 0) {
    req.scopeFilter.lga = { $in: lgas };
  }

  next();
}

module.exports = { scopeFilter };
