'use strict';
const http        = require('http');
const express     = require('express');
const helmet      = require('helmet');
const cors        = require('cors');
const compression = require('compression');
const morgan      = require('morgan');

const env           = require('./config/env');
const { connectDB } = require('./config/db');
const { getRedis }  = require('./config/redis');
const { initRealtime } = require('./sockets/realtime');

// Routes
const authRoute      = require('./routes/auth');
const assetsRoute    = require('./routes/assets');
const photosRoute    = require('./routes/photos');
const excelRoute     = require('./routes/excel');
const spatialRoute   = require('./routes/spatial');
const analyticsRoute = require('./routes/analytics');
const ocrRoute       = require('./routes/ocr');
const exportRoute    = require('./routes/export');
const documentsRoute = require('./routes/documents');
const usersRoute     = require('./routes/users');
const auditRoute     = require('./routes/audit');
const settingsRoute  = require('./routes/settings');

const app = express();

// ── Security & compression ────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: (origin, cb) => {
    // Allow: configured CLIENT_URL, any localhost port, null (file:// or Postman)
    const allowed = !origin
      || origin === env.CLIENT_URL
      || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
    cb(null, allowed);
  },
  credentials: true,
}));
app.use(compression());

// ── Logging ───────────────────────────────────────────────────────────────────
app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Body parsers ──────────────────────────────────────────────────────────────
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Health check (no auth) ────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', ts: new Date() }));

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api/auth',      authRoute);
app.use('/api/assets',    assetsRoute);
app.use('/api/assets',    exportRoute);        // /api/assets/export
app.use('/api/assets/spatial', spatialRoute);

// File sub-routes (mergeParams enabled in each router)
app.use('/api/assets/:assetId/photos',     photosRoute);
app.use('/api/assets/:assetId/documents', documentsRoute);
app.use('/api/assets/:assetId/excel',     excelRoute);

app.use('/api/analytics', analyticsRoute);
app.use('/api/ocr',       ocrRoute);
app.use('/api/users',     usersRoute);
app.use('/api/audit',     auditRoute);
app.use('/api/settings',  settingsRoute);

// ── Global error handler ──────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const message = env.NODE_ENV === 'production' && status === 500
    ? 'Internal server error'
    : err.message;

  if (status === 500) console.error('[Error]', err);

  res.status(status).json({ error: message });
});

// ── Bootstrap ─────────────────────────────────────────────────────────────────
async function start() {
  await connectDB();
  // Redis connects lazily on first use (optional — falls back to memory)

  const server = http.createServer(app);
  initRealtime(server);

  server.listen(env.PORT, () => {
    console.log(`[AssetSpatial] API running on port ${env.PORT} (${env.NODE_ENV})`);
  });

  // Graceful shutdown
  const shutdown = async (signal) => {
    console.log(`[AssetSpatial] ${signal} received — shutting down`);
    server.close(() => process.exit(0));
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT',  () => shutdown('SIGINT'));
}

start().catch((err) => {
  console.error('[AssetSpatial] Failed to start:', err);
  process.exit(1);
});

module.exports = app;  // for tests
