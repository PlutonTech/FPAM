'use strict';
const { isRedisAvailable, getRedis } = require('../config/redis');
const ocrService = require('../services/ocrService');

// In-memory fallback queue for when Redis is unavailable
const _memJobs = new Map();
let _jobCounter = 1;

let _bullQueue = null;

function getBullQueue() {
  if (_bullQueue) return _bullQueue;
  if (!isRedisAvailable()) return null;
  try {
    const Bull = require('bull');
    _bullQueue = new Bull('ocr', { createClient: () => getRedis() });
    _bullQueue.process(async (job) => {
      const { buffer, mimeType } = job.data;
      const buf         = Buffer.from(buffer, 'base64');
      const text        = await ocrService.extractText(buf, mimeType);
      const suggestions = ocrService.suggestFields(text);
      return { text, suggestions };
    });
    _bullQueue.on('failed', (job, err) => console.error(`[OCR Queue] Job ${job.id} failed:`, err.message));
    return _bullQueue;
  } catch (e) {
    console.warn('[OCR Queue] Bull unavailable, using in-memory queue:', e.message);
    return null;
  }
}

async function enqueueOCR(buffer, mimeType) {
  const q = getBullQueue();
  if (q) {
    const job = await q.add(
      { buffer: buffer.toString('base64'), mimeType },
      { attempts: 2, backoff: { type: 'exponential', delay: 3000 } }
    );
    return String(job.id);
  }

  // In-memory fallback — process synchronously
  const jobId = String(_jobCounter++);
  _memJobs.set(jobId, { state: 'active' });

  // Process async but immediately
  setImmediate(async () => {
    try {
      const text        = await ocrService.extractText(buffer, mimeType);
      const suggestions = ocrService.suggestFields(text);
      _memJobs.set(jobId, { state: 'completed', result: { text, suggestions } });
    } catch (err) {
      _memJobs.set(jobId, { state: 'failed', failReason: err.message });
    }
  });

  return jobId;
}

async function getJobStatus(jobId) {
  const q = getBullQueue();
  if (q) {
    const job = await q.getJob(jobId);
    if (!job) return null;
    const state      = await job.getState();
    const result     = state === 'completed' ? job.returnvalue : null;
    const failReason = state === 'failed'    ? job.failedReason : null;
    return { jobId, state, result, failReason };
  }

  // In-memory fallback
  const job = _memJobs.get(jobId);
  if (!job) return null;
  return { jobId, ...job };
}

module.exports = { enqueueOCR, getJobStatus };
