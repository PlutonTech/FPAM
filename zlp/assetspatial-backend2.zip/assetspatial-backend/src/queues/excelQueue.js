'use strict';
const { isRedisAvailable, getRedis } = require('../config/redis');
const excelService = require('../services/excelService');

const _memJobs = new Map();
let _jobCounter = 1;
let _bullQueue  = null;

function getBullQueue() {
  if (_bullQueue) return _bullQueue;
  if (!isRedisAvailable()) return null;
  try {
    const Bull = require('bull');
    _bullQueue = new Bull('excel', { createClient: () => getRedis() });
    _bullQueue.process(async (job) => {
      const { buffer, mimeType } = job.data;
      const buf    = Buffer.from(buffer, 'base64');
      const result = await excelService.parseBuffer(buf, mimeType);
      return result;
    });
    return _bullQueue;
  } catch {
    return null;
  }
}

async function enqueueExcel(buffer, mimeType) {
  const q = getBullQueue();
  if (q) {
    const job = await q.add(
      { buffer: buffer.toString('base64'), mimeType },
      { attempts: 1 }
    );
    return String(job.id);
  }

  const jobId = String(_jobCounter++);
  _memJobs.set(jobId, { state: 'active' });
  setImmediate(async () => {
    try {
      const result = await excelService.parseBuffer(buffer, mimeType);
      _memJobs.set(jobId, { state: 'completed', result });
    } catch (err) {
      _memJobs.set(jobId, { state: 'failed', failReason: err.message });
    }
  });
  return jobId;
}

async function getJobStatus(jobId) {
  const q = getBullQueue();
  if (q) {
    const job = await q.getJob(jobId);
    if (!job) return null;
    const state = await job.getState();
    return { jobId, state, result: state === 'completed' ? job.returnvalue : null };
  }
  const job = _memJobs.get(jobId);
  if (!job) return null;
  return { jobId, ...job };
}

module.exports = { enqueueExcel, getJobStatus };
