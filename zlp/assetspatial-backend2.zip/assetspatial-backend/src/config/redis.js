'use strict';
const Redis = require('ioredis');
const env   = require('./env');

let _client = null;
let _available = true;

function getRedis() {
  if (_client) return _client;

  _client = new Redis(env.REDIS_URL, {
    maxRetriesPerRequest: null,
    enableReadyCheck: false,
    lazyConnect: false,
    retryStrategy: (times) => {
      // Stop retrying after 3 attempts — fall back to memory
      if (times > 3) { _available = false; return null; }
      return Math.min(times * 500, 2000);
    },
  });

  _client.on('connect',  ()  => { console.log('[Redis] Connected'); _available = true; });
  _client.on('error',    (e) => {
    if (_available) console.warn('[Redis] Unavailable — rate limiting will use memory fallback:', e.code);
    _available = false;
  });

  return _client;
}

function isRedisAvailable() { return _available; }

module.exports = { getRedis, isRedisAvailable };
