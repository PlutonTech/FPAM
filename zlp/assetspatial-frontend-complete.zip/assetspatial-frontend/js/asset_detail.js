// ── ASSET DETAIL MODAL — Full Production Port ─────────────────────────────────
// Replaces all IndexedDB / localStorage logic with GridFS API calls

// ── HELPERS ───────────────────────────────────────────────────────────────────
function calcRiskScore(a) {
  let score = 0;
  if (a.condition === 'Critical')  score += 40;
  else if (a.condition === 'Poor') score += 25;
  else if (a.condition === 'Fair') score += 10;
  if (a.nextInspection) {
    const daysLeft = Math.round((new Date(a.nextInspection) - new Date()) / 86400000);
    if (daysLeft < 0)  score += 30;
    else if (daysLeft < 30) score += 15;
  }
  if (a.type === 'Infrastructure') score += 10;
  else if (a.type === 'Utility')   score += 8;
  return Math.min(score, 100);
}

function riskBadge(score) {
  if (score >= 60) return `<span class="tag tag-red" title="Risk score: ${score}/100"><i class="fa-solid fa-circle-exclamation"></i> HIGH ${score}</span>`;
  if (score >= 30) return `<span class="tag tag-warn" title="Risk score: ${score}/100"><i class="fa-solid fa-triangle-exclamation"></i> MED ${score}</span>`;
  return `<span class="tag tag-green" title="Risk score: ${score}/100"><i class="fa-solid fa-circle-check"></i> LOW ${score}</span>`;
}

// ── ASSET DETAIL MODAL ────────────────────────────────────────────────────────
function showAssetDetail(a) {
  if (!a) return;
  const id  = a.assetId || a.id;
  const lat = a.lat || a.location?.coordinates?.[1];
  const lng = a.lng || a.location?.coordinates?.[0];
  const mapsLink = (lat && lng && !isNaN(lat) && !isNaN(lng))
    ? `<a class="btn btn-secondary btn-sm" href="https://www.google.com/maps/search/?api=1&query=${lat},${lng}" target="_blank"><i class="fa-solid fa-map-location-dot"></i> Google Maps</a>`
    : '';

  openModal(escHtml(a.name || id), `
    <div style="display:flex;border-bottom:1px solid var(--border);margin-bottom:16px;gap:0;overflow-x:auto">
      <button class="dtab-btn active" data-tab="info"    onclick="switchDetailTab('info',this)">    <i class="fa-solid fa-circle-info"></i> Info</button>
      <button class="dtab-btn"        data-tab="maint"   onclick="switchDetailTab('maint',this)">  <i class="fa-solid fa-wrench"></i> Maintenance</button>
      <button class="dtab-btn"        data-tab="history" onclick="switchDetailTab('history',this)"><i class="fa-solid fa-chart-line"></i> History</button>
      <button class="dtab-btn"        data-tab="photos"  onclick="switchDetailTab('photos',this)"> <i class="fa-solid fa-camera"></i> Photos</button>
      <button class="dtab-btn"        data-tab="excel"   onclick="switchDetailTab('excel',this)">  <i class="fa-solid fa-file-excel"></i> Excel</button>
      <button class="dtab-btn"        data-tab="valuation" onclick="switchDetailTab('valuation',this)"><i class="fa-solid fa-naira-sign"></i> Valuation</button>
    </div>

    <!-- INFO TAB -->
    <div id="dtab-info" class="dtab-content" style="display:block">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px">
        ${_detailRow('Asset ID',     `<span style="font-family:'Space Mono',monospace;color:var(--accent)">${escHtml(id)}</span>`)}
        ${_detailRow('Status',       `<span class="tag ${(a.status||'Active')==='Active'?'tag-green':'tag-gray'}">${escHtml(a.status||'Active')}</span>`)}
        ${_detailRow('Type',         `<span class="tag ${typeColor(a.type)}">${escHtml(a.type)}</span>`)}
        ${_detailRow('Condition',    `<span class="tag ${condColor(a.condition)}">${escHtml(a.condition)}</span>`)}
        ${_detailRow('Risk',         riskBadge(calcRiskScore(a)))}
        ${_detailRow('Geometry',     `<i class="fa-solid ${geomIcon(a.geomType||a.geom)}" style="margin-right:5px"></i>${escHtml(a.geomType||a.geom||'—')}`)}
        ${_detailRow('State',        escHtml(a.state||'—'))}
        ${_detailRow('LGA',          escHtml(a.lga||'—'))}
        ${_detailRow('Address',      escHtml(a.address||'—'), true)}
        ${_detailRow('Material',     escHtml(a.material||'—'))}
        ${_detailRow('Area/Dim',     escHtml(a.area||'—'))}
        ${_detailRow('Captured By',  escHtml(a.agent||a.capturedBy?.name||'—'))}
        ${_detailRow('Capture Date', escHtml(a.date||a.captureDate||'—'))}
        ${(lat&&lng)?_detailRow('Coordinates',`<span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--accent)">${Number(lat).toFixed(6)}°N, ${Number(lng).toFixed(6)}°E</span>`,true):''}
        ${a.nextInspection?_detailRow('Next Inspection',`<span style="color:${new Date(a.nextInspection)<new Date()?'var(--danger)':'var(--warn)'}">${escHtml(a.nextInspection)}</span>`):''}
        ${a.notes?_detailRow('Notes',escHtml(a.notes),true):''}
      </div>
      ${a.typeData&&Object.keys(a.typeData).length?`
        <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border)">
          <div style="font-family:'Space Mono',monospace;font-size:9px;color:var(--accent);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px">Type-Specific Fields</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px">
            ${Object.entries(a.typeData).map(([k,v])=>_detailRow(escHtml(k),escHtml(v))).join('')}
          </div>
        </div>`:''}
    </div>

    <!-- MAINTENANCE TAB -->
    <div id="dtab-maint" class="dtab-content" style="display:none">
      <div id="maint-content-${id}">
        <div style="text-align:center;padding:20px"><div class="spinner"></div></div>
      </div>
    </div>

    <!-- HISTORY TAB -->
    <div id="dtab-history" class="dtab-content" style="display:none">
      <div id="history-content-${id}">
        ${_buildConditionHistory(a)}
      </div>
    </div>

    <!-- PHOTOS TAB -->
    <div id="dtab-photos" class="dtab-content" style="display:none">
      <div id="photo-gallery-${id}">
        <div style="text-align:center;padding:24px;color:var(--text3)"><div class="spinner"></div></div>
      </div>
    </div>

    <!-- EXCEL DATA TAB -->
    <div id="dtab-excel" class="dtab-content" style="display:none">
      <div id="excel-content-${id}">
        <div style="text-align:center;padding:24px;color:var(--text3)"><div class="spinner"></div></div>
      </div>
    </div>

    <!-- VALUATION TAB -->
    <div id="dtab-valuation" class="dtab-content" style="display:none">
      ${_buildValuationTab(a)}
    </div>
  `,
  `<button class="btn btn-ghost" onclick="closeModal()">Close</button>
   ${mapsLink}
   <button class="btn btn-secondary btn-sm" onclick="openQRModal('${id}')"><i class="fa-solid fa-qrcode"></i> QR</button>
   <button class="btn btn-secondary btn-sm" onclick="closeModal();openEditAsset(${JSON.stringify(a).replace(/'/g,"&#39;")})"><i class="fa-solid fa-pen"></i> Edit</button>
   <button class="btn btn-danger btn-sm" onclick="deleteAsset('${id}');closeModal()"><i class="fa-solid fa-trash"></i> Delete</button>`
  );

  // Load maintenance immediately (already in the asset object usually)
  _renderMaintenanceTab(id, a);

  // Add tab button styles
  document.querySelectorAll('.dtab-btn').forEach(b => {
    b.style.cssText = 'background:none;border:none;border-bottom:2px solid transparent;padding:9px 14px;font-size:12.5px;color:var(--text2);cursor:pointer;font-family:"Space Grotesk",sans-serif;display:flex;align-items:center;gap:6px;white-space:nowrap;transition:all .15s';
  });
  document.querySelector('.dtab-btn.active').style.cssText += ';color:var(--accent);border-bottom-color:var(--accent)';
}

function _detailRow(label, value, fullWidth = false) {
  return `<div ${fullWidth?'style="grid-column:1/-1"':''}>
    <div style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px">${label}</div>
    <div style="font-size:13px;color:var(--text)">${value}</div>
  </div>`;
}

function switchDetailTab(tab, btn) {
  document.querySelectorAll('.dtab-content').forEach(el => el.style.display = 'none');
  const el = document.getElementById('dtab-' + tab);
  if (el) el.style.display = 'block';

  document.querySelectorAll('.dtab-btn').forEach(b => {
    b.style.cssText = 'background:none;border:none;border-bottom:2px solid transparent;padding:9px 14px;font-size:12.5px;color:var(--text2);cursor:pointer;font-family:"Space Grotesk",sans-serif;display:flex;align-items:center;gap:6px;white-space:nowrap;transition:all .15s';
    b.classList.remove('active');
  });
  if (btn) {
    btn.style.cssText += ';color:var(--accent);border-bottom-color:var(--accent)';
    btn.classList.add('active');
  }

  const tabData = btn?.dataset?.tab;
  const modalBody = document.querySelector('.modal-body');
  const assetId   = modalBody?.querySelector('[id^="dtab-"]')?.id?.split('-').pop();

  // Lazy load tabs
  if (tab === 'photos'  && assetId) _loadPhotoGallery(assetId);
  if (tab === 'excel'   && assetId) _loadExcelTab(assetId);
}

// ── PHOTO GALLERY ─────────────────────────────────────────────────────────────
async function _loadPhotoGallery(assetId) {
  const el = document.getElementById(`photo-gallery-${assetId}`);
  if (!el || el.dataset.loaded) return;
  el.dataset.loaded = '1';

  try {
    const r = await apiFetch(`/assets/${assetId}/photos`);
    const photos = r.files || r.photos || [];
    _renderPhotoGallery(assetId, photos, el);
  } catch {
    el.innerHTML = `<div style="color:var(--text3);font-size:12px;text-align:center;padding:20px">Could not load photos (API offline)</div>
      <div style="margin-top:12px">${_photoUploadControls(assetId)}</div>`;
  }
}

function _renderPhotoGallery(assetId, photos, container) {
  const el = container || document.getElementById(`photo-gallery-${assetId}`);
  if (!el) return;

  const grid = photos.length
    ? `<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
        ${photos.map(p => {
          const url = `${API_BASE}/assets/${assetId}/photos/${p._id||p.id}`;
          return `<div style="position:relative;width:90px;height:90px;border-radius:6px;overflow:hidden;border:1px solid var(--border);cursor:pointer;background:var(--surface2)" onclick="openLightbox('${url}')">
            <img src="${url}" style="width:100%;height:100%;object-fit:cover" loading="lazy" onerror="this.parentElement.innerHTML='<div style=font-size:20px;text-align:center;padding:30px><i class=fa-solid\\ fa-image></i></div>'">
            <button onclick="event.stopPropagation();deleteAssetPhoto('${assetId}','${p._id||p.id}',this.closest('div[style]'))"
              style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,.65);color:#fff;border:none;border-radius:50%;width:22px;height:22px;font-size:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .15s"
              onmouseenter="this.style.opacity=1" onmouseleave="this.style.opacity=0">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>`;
        }).join('')}
      </div>`
    : `<div style="text-align:center;padding:24px;color:var(--text3)"><i class="fa-solid fa-camera" style="font-size:28px;margin-bottom:10px;display:block"></i>No photos yet</div>`;

  el.innerHTML = grid + _photoUploadControls(assetId);
}

function _photoUploadControls(assetId) {
  return `<div style="display:flex;gap:8px;flex-wrap:wrap">
    <label class="btn btn-secondary btn-sm" style="cursor:pointer">
      <i class="fa-solid fa-image"></i> Add Photo
      <input type="file" accept="image/*" multiple style="display:none" onchange="uploadAssetPhotos('${assetId}',this.files)">
    </label>
    <label class="btn btn-secondary btn-sm" style="cursor:pointer">
      <i class="fa-solid fa-camera"></i> Camera
      <input type="file" accept="image/*" capture="environment" style="display:none" onchange="uploadAssetPhotos('${assetId}',this.files)">
    </label>
  </div>`;
}

async function uploadAssetPhotos(assetId, files) {
  if (!files?.length) return;
  let uploaded = 0;
  for (const file of files) {
    try {
      const fd = new FormData(); fd.append('photo', file);
      await apiFetchRaw(`/assets/${assetId}/photos`, { method:'POST', body:fd });
      uploaded++;
    } catch {}
  }
  toast(`${uploaded} photo(s) uploaded`);
  addAudit('PHOTO_ATTACHED', assetId, null, `${uploaded} photo(s) added`);
  // Reload gallery
  const el = document.getElementById(`photo-gallery-${assetId}`);
  if (el) { el.dataset.loaded = ''; _loadPhotoGallery(assetId); }
}

async function deleteAssetPhoto(assetId, photoId, thumbEl) {
  if (!confirm('Delete this photo?')) return;
  try {
    await apiFetch(`/assets/${assetId}/photos/${photoId}`, { method:'DELETE' });
    thumbEl?.remove();
    toast('Photo deleted');
    addAudit('PHOTO_DELETED', assetId, null, 'Photo removed');
  } catch(e) {
    toast('Could not delete photo: ' + e.message, 'fa-circle-xmark', true);
  }
}

function openLightbox(src) {
  const lb = document.createElement('div');
  lb.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:9999;display:flex;align-items:center;justify-content:center;cursor:zoom-out;backdrop-filter:blur(4px)';
  lb.innerHTML = `<img src="${src}" style="max-width:92vw;max-height:88vh;border-radius:8px;box-shadow:0 24px 80px rgba(0,0,0,.6)">
    <button onclick="this.parentElement.remove()" style="position:absolute;top:20px;right:24px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;border-radius:50%;width:36px;height:36px;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center"><i class="fa-solid fa-xmark"></i></button>`;
  lb.addEventListener('click', e => { if (e.target === lb) lb.remove(); });
  document.body.appendChild(lb);
}

// ── MAINTENANCE TAB ───────────────────────────────────────────────────────────
async function _renderMaintenanceTab(assetId, a) {
  const el = document.getElementById(`maint-content-${assetId}`);
  if (!el) return;

  let logs = a.maintenanceLogs || [];
  try {
    const r = await apiFetch(`/assets/${assetId}`);
    logs = r.asset?.maintenanceLogs || logs;
  } catch {}

  const total = logs.reduce((s, l) => s + Number(l.cost || l.amount || 0), 0);

  el.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
      <div style="font-size:12px;color:var(--text2)"><strong>${logs.length}</strong> maintenance entries</div>
      <div style="font-family:'Space Mono',monospace;font-size:11px;color:var(--accent)">Total: ₦${total.toLocaleString()}</div>
    </div>

    <!-- Add entry form -->
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:14px;margin-bottom:14px">
      <div style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">Add New Entry</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Description *</label>
          <input class="form-control" id="ml-desc-${assetId}" placeholder="What was done"></div>
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Date</label>
          <input class="form-control" id="ml-date-${assetId}" type="date" value="${new Date().toISOString().split('T')[0]}"></div>
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Technician</label>
          <input class="form-control" id="ml-tech-${assetId}" placeholder="Name"></div>
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Cost (₦)</label>
          <input class="form-control" id="ml-cost-${assetId}" type="number" placeholder="0"></div>
      </div>
      <button class="btn btn-primary btn-sm" style="width:100%" onclick="addMaintenanceEntry('${assetId}')">
        <i class="fa-solid fa-plus"></i> Add Entry
      </button>
    </div>

    <!-- Log table -->
    <div class="table-wrap" style="margin-bottom:0">
      <table class="data-table">
        <thead><tr><th>Date</th><th>Description</th><th>Technician</th><th>Cost (₦)</th><th></th></tr></thead>
        <tbody id="maint-tbody-${assetId}">
          ${logs.length
            ? logs.map((l, i) => `<tr>
                <td style="font-family:'Space Mono',monospace;font-size:10px">${escHtml(l.date||l.performedAt?.slice(0,10)||'—')}</td>
                <td>${escHtml(l.desc||l.description||'—')}</td>
                <td>${escHtml(l.tech||l.technician||'—')}</td>
                <td style="font-family:'Space Mono',monospace;font-size:11px;color:var(--accent)">₦${Number(l.cost||l.amount||0).toLocaleString()}</td>
                <td><button class="btn btn-danger btn-xs" onclick="deleteMaintenanceEntry('${assetId}',${i})"><i class="fa-solid fa-trash"></i></button></td>
              </tr>`).join('')
            : '<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text3)">No maintenance records yet</td></tr>'
          }
        </tbody>
      </table>
    </div>`;
}

async function addMaintenanceEntry(assetId) {
  const desc = document.getElementById(`ml-desc-${assetId}`)?.value.trim();
  const date = document.getElementById(`ml-date-${assetId}`)?.value;
  const tech = document.getElementById(`ml-tech-${assetId}`)?.value;
  const cost = parseFloat(document.getElementById(`ml-cost-${assetId}`)?.value) || 0;
  if (!desc) { toast('Description is required', 'fa-triangle-exclamation', true); return; }

  const entry = { desc, date, tech, cost, amount: cost };
  try {
    await apiAddMaintenance(assetId, entry);
    toast('Maintenance entry added');
  } catch {
    const a = assets.find(x=>(x.assetId||x.id)===assetId);
    if (a) { a.maintenanceLogs = a.maintenanceLogs||[]; a.maintenanceLogs.push(entry); saveLocal(); }
    toast('Saved locally');
  }
  addAudit('MAINTENANCE_LOGGED', assetId, null, desc);
  // Refresh tab
  const asset = assets.find(x=>(x.assetId||x.id)===assetId) || {};
  asset.maintenanceLogs = [...(asset.maintenanceLogs||[]), entry];
  _renderMaintenanceTab(assetId, asset);
}

async function deleteMaintenanceEntry(assetId, idx) {
  if (!confirm('Remove this maintenance entry?')) return;
  try {
    await apiFetch(`/assets/${assetId}/maintenance/${idx}`, { method:'DELETE' });
    toast('Entry removed');
  } catch {
    const a = assets.find(x=>(x.assetId||x.id)===assetId);
    if (a?.maintenanceLogs) { a.maintenanceLogs.splice(idx,1); saveLocal(); }
    toast('Removed locally');
  }
  addAudit('MAINTENANCE_DELETED', assetId, null, `Entry #${idx} removed`);
  // Refresh tab
  const asset = assets.find(x=>(x.assetId||x.id)===assetId) || {};
  _renderMaintenanceTab(assetId, asset);
}

// ── CONDITION HISTORY ─────────────────────────────────────────────────────────
function _buildConditionHistory(a) {
  const history = a.conditionHistory || [];
  if (!history.length) {
    return `<div style="text-align:center;padding:32px;color:var(--text3)">
      <i class="fa-solid fa-chart-line" style="font-size:28px;margin-bottom:10px;display:block;color:var(--border2)"></i>
      <div style="font-size:13px;font-weight:500;color:var(--text2);margin-bottom:5px">No condition changes recorded</div>
      <div style="font-size:11px">Edit this asset and change its condition to start tracking.</div>
    </div>`;
  }
  const COLORS = { Good:'var(--accent)', Fair:'var(--warn)', Poor:'rgba(240,120,0,.9)', Critical:'var(--danger)' };
  const all = [{ from:null, to:history[0]?.from, ts: a.ts||a.createdAt, user: a.agent||'System' }, ...history];
  return `<div style="padding-left:16px;border-left:2px solid var(--border)">
    ${all.map(h => `<div style="position:relative;padding:0 0 18px 20px">
      <div style="position:absolute;left:-5px;top:4px;width:8px;height:8px;border-radius:50%;background:${COLORS[h.to]||'var(--border2)'};box-shadow:0 0 6px ${COLORS[h.to]||'transparent'}"></div>
      <div style="font-size:13px;font-weight:600;color:var(--text)">
        ${h.to ? `→ <span style="color:${COLORS[h.to]}">${escHtml(h.to)}</span>` : '<span style="color:var(--text3)">Initial capture</span>'}
      </div>
      ${h.from ? `<div style="font-size:11px;color:var(--text3)">from ${escHtml(h.from)}</div>` : ''}
      <div style="font-size:10px;color:var(--text3);font-family:'Space Mono',monospace;margin-top:3px">
        ${new Date(h.ts||h.changedAt||Date.now()).toLocaleString('en-NG')} · ${escHtml(h.user||h.changedBy?.name||'—')}
      </div>
    </div>`).join('')}
  </div>`;
}

// ── EXCEL DATA TAB ────────────────────────────────────────────────────────────
async function _loadExcelTab(assetId) {
  const el = document.getElementById(`excel-content-${assetId}`);
  if (!el || el.dataset.loaded) return;
  el.dataset.loaded = '1';

  try {
    const r = await apiFetch(`/assets/${assetId}/excel`);
    const files = r.files || r.excel || [];
    if (!files.length) {
      el.innerHTML = `<div style="text-align:center;padding:32px;color:var(--text3)">
        <i class="fa-solid fa-file-excel" style="font-size:28px;margin-bottom:10px;display:block;color:var(--border2)"></i>
        <div style="font-size:13px;color:var(--text2);margin-bottom:6px">No Excel data attached</div>
        <div style="font-size:11px">Use the <a href="excel.html" style="color:var(--accent)">Excel Import</a> page and target this asset.</div>
      </div>`;
      return;
    }

    el.innerHTML = files.map((f, i) => {
      const name = f.originalname || f.filename || `Excel Import ${i+1}`;
      const url  = `${API_BASE}/assets/${assetId}/excel/${f._id||f.id}`;
      const date = new Date(f.uploadDate||f.createdAt||Date.now()).toLocaleString('en-NG');
      return `<div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:14px;margin-bottom:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
          <div>
            <div style="font-weight:600;font-size:13px"><i class="fa-solid fa-file-excel" style="color:#1d6f42;margin-right:6px"></i>${escHtml(name)}</div>
            <div style="font-size:10px;color:var(--text3);font-family:'Space Mono',monospace;margin-top:2px">${date}</div>
          </div>
          <div style="display:flex;gap:6px">
            <a href="${url}" target="_blank" class="btn btn-secondary btn-xs"><i class="fa-solid fa-download"></i> Download</a>
            <button class="btn btn-danger btn-xs" onclick="deleteAssetExcel('${assetId}','${f._id||f.id}',this.closest('div[style]'))"><i class="fa-solid fa-trash"></i></button>
          </div>
        </div>
        <div id="excel-preview-${f._id||f.id}" style="font-size:11px;color:var(--text3)">
          <button class="btn btn-ghost btn-xs" onclick="loadExcelPreview('${assetId}','${f._id||f.id}')"><i class="fa-solid fa-eye"></i> Preview rows</button>
        </div>
      </div>`;
    }).join('');
  } catch {
    el.innerHTML = `<div style="color:var(--text3);font-size:12px;text-align:center;padding:20px">Could not load Excel files (API offline)</div>`;
  }
}

async function loadExcelPreview(assetId, fileId) {
  const el = document.getElementById(`excel-preview-${fileId}`);
  if (!el) return;
  el.innerHTML = '<div class="spinner" style="margin:8px auto"></div>';
  try {
    const r = await apiFetch(`/assets/${assetId}/excel/${fileId}?preview=true`);
    const rows = r.rows || r.preview || [];
    const headers = r.headers || (rows[0] ? Object.keys(rows[0]) : []);
    if (!rows.length) { el.textContent = 'No rows in preview'; return; }
    el.innerHTML = `<div style="overflow-x:auto;margin-top:8px"><table class="data-table" style="font-size:11px;white-space:nowrap">
      <thead><tr>${headers.map(h=>`<th>${escHtml(h)}</th>`).join('')}</tr></thead>
      <tbody>${rows.slice(0,8).map(row=>`<tr>${headers.map(h=>`<td>${escHtml(String(row[h]||'—'))}</td>`).join('')}</tr>`).join('')}</tbody>
    </table>${rows.length>8?`<div style="font-size:10px;color:var(--text3);padding:6px">…and ${rows.length-8} more rows</div>`:''}</div>`;
  } catch {
    el.textContent = 'Could not load preview';
  }
}

async function deleteAssetExcel(assetId, fileId, cardEl) {
  if (!confirm('Remove this Excel file?')) return;
  try {
    await apiFetch(`/assets/${assetId}/excel/${fileId}`, { method:'DELETE' });
    cardEl?.remove();
    toast('Excel file removed');
  } catch(e) {
    toast('Could not delete: ' + e.message, 'fa-circle-xmark', true);
  }
}

// ── VALUATION TAB ─────────────────────────────────────────────────────────────
function _buildValuationTab(a) {
  const v = a.valuation || {};
  return `<div>
    ${v.amount ? `<div style="background:var(--accent3);border:1px solid rgba(0,200,100,.2);border-radius:8px;padding:14px;margin-bottom:16px;display:flex;align-items:center;gap:10px">
      <i class="fa-solid fa-naira-sign" style="color:var(--accent);font-size:18px"></i>
      <div><div style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);text-transform:uppercase;margin-bottom:2px">Current Valuation</div>
        <div style="font-size:22px;font-weight:700;color:var(--accent)">₦${Number(v.amount).toLocaleString()}</div>
        <div style="font-size:11px;color:var(--text3)">${escHtml(v.method||'—')} · ${escHtml(v.valuedAt?.slice(0,10)||v.valuationDate||'—')}</div>
      </div>
    </div>` : ''}

    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:14px">
      <div style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);text-transform:uppercase;margin-bottom:12px">Set / Update Valuation</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Amount (₦) *</label>
          <input class="form-control" id="val-amount-${a.assetId||a.id}" type="number" placeholder="e.g. 5000000" value="${v.amount||''}"></div>
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Valuation Method</label>
          <select class="form-control" id="val-method-${a.assetId||a.id}">
            ${['Market Value','Replacement Cost','Income Approach','Book Value','Professional Estimate'].map(m=>`<option ${v.method===m?'selected':''}>${m}</option>`).join('')}
          </select></div>
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Valuation Date</label>
          <input class="form-control" id="val-date-${a.assetId||a.id}" type="date" value="${v.valuedAt?.slice(0,10)||v.valuationDate||new Date().toISOString().split('T')[0]}"></div>
        <div><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Valued By</label>
          <input class="form-control" id="val-by-${a.assetId||a.id}" placeholder="Name of valuer" value="${escHtml(v.valuedBy||'')}"></div>
        <div style="grid-column:1/-1"><label style="font-family:'Space Mono',monospace;font-size:9px;color:var(--text3);display:block;margin-bottom:4px;text-transform:uppercase">Notes</label>
          <input class="form-control" id="val-notes-${a.assetId||a.id}" placeholder="Optional notes" value="${escHtml(v.notes||'')}"></div>
      </div>
      <button class="btn btn-primary" style="width:100%;margin-top:12px" onclick="saveValuation('${a.assetId||a.id}')">
        <i class="fa-solid fa-floppy-disk"></i> Save Valuation
      </button>
    </div>
  </div>`;
}

async function saveValuation(assetId) {
  const amount  = parseFloat(document.getElementById(`val-amount-${assetId}`)?.value);
  const method  = document.getElementById(`val-method-${assetId}`)?.value;
  const date    = document.getElementById(`val-date-${assetId}`)?.value;
  const valuedBy= document.getElementById(`val-by-${assetId}`)?.value;
  const notes   = document.getElementById(`val-notes-${assetId}`)?.value;
  if (!amount || isNaN(amount)) { toast('Enter a valid amount', 'fa-triangle-exclamation', true); return; }

  const data = { amount, method, valuedAt: date, valuationDate: date, valuedBy, notes };
  try {
    await apiUpdateValuation(assetId, data);
    toast(`Valuation set: ₦${amount.toLocaleString()}`);
  } catch {
    const a = assets.find(x=>(x.assetId||x.id)===assetId);
    if (a) { a.valuation = data; saveLocal(); }
    toast('Saved locally');
  }
  addAudit('VALUATION_UPDATED', assetId, null, `₦${amount.toLocaleString()} via ${method}`);
}

// ── QR CODE ───────────────────────────────────────────────────────────────────
let _qrAssetId = null;
let _qrAsset   = null;

function openQRModal(assetId) {
  _qrAssetId = assetId;
  _qrAsset   = assets.find(x => (x.assetId||x.id) === assetId) || { id: assetId };

  const qrData = JSON.stringify({
    id:   _qrAsset.assetId || _qrAsset.id,
    name: _qrAsset.name,
    type: _qrAsset.type,
    lat:  _qrAsset.lat || _qrAsset.location?.coordinates?.[1],
    lng:  _qrAsset.lng || _qrAsset.location?.coordinates?.[0],
    app:  'AssetSpatial',
    url:  `${location.origin}/assets.html?id=${assetId}`,
  });

  // Build QR modal
  const overlay = document.createElement('div');
  overlay.id = 'qr-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:2000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)';
  overlay.innerHTML = `
    <div style="background:var(--surface);border:1px solid var(--border2);border-radius:14px;padding:28px;text-align:center;width:320px;max-width:95vw;box-shadow:0 24px 80px rgba(0,0,0,.5)">
      <div style="font-family:'Syne',sans-serif;font-size:17px;font-weight:800;margin-bottom:4px">${escHtml(_qrAsset.name||assetId)}</div>
      <div style="font-family:'Space Mono',monospace;font-size:10px;color:var(--text3);margin-bottom:16px">${escHtml(assetId)}</div>
      <canvas id="qr-canvas" width="200" height="200" style="border:4px solid #fff;border-radius:8px;margin-bottom:16px"></canvas>
      <div style="font-size:11px;color:var(--text3);margin-bottom:18px">Scan to open asset record</div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="downloadQR()"><i class="fa-solid fa-download"></i> Download</button>
        <button class="btn btn-secondary btn-sm" onclick="window.print()"><i class="fa-solid fa-print"></i> Print</button>
        <button class="btn btn-ghost btn-sm" onclick="document.getElementById('qr-overlay').remove()"><i class="fa-solid fa-xmark"></i> Close</button>
      </div>
    </div>`;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);

  // Draw QR
  const canvas = document.getElementById('qr-canvas');
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0,0,200,200);

  if (window.QRCode) {
    const tmp = document.createElement('div');
    tmp.style.display = 'none';
    document.body.appendChild(tmp);
    try {
      new QRCode(tmp, { text: qrData, width:200, height:200, colorDark:'#000', colorLight:'#fff', correctLevel: QRCode.CorrectLevel.M });
      setTimeout(() => {
        const img = tmp.querySelector('img') || tmp.querySelector('canvas');
        if (img?.tagName === 'CANVAS') {
          ctx.drawImage(img, 0, 0, 200, 200);
        } else if (img) {
          const i = new Image(); i.onload = ()=>ctx.drawImage(i,0,0,200,200); i.src=img.src;
        }
        tmp.remove();
      }, 150);
    } catch { tmp.remove(); _drawQRFallback(ctx, assetId); }
  } else {
    _drawQRFallback(ctx, assetId);
  }
}

function _drawQRFallback(ctx, assetId) {
  ctx.fillStyle = '#fff'; ctx.fillRect(0,0,200,200);
  ctx.fillStyle = '#0f2e1c';
  ctx.font = 'bold 12px monospace'; ctx.textAlign = 'center';
  ctx.fillText('AssetSpatial', 100, 80);
  ctx.font = '11px monospace';
  ctx.fillText(assetId, 100, 100);
  ctx.font = '9px monospace'; ctx.fillStyle = '#4a6b5a';
  ctx.fillText('Install qrcode.min.js', 100, 125);
  ctx.fillText('for real QR code', 100, 140);
}

function downloadQR() {
  const canvas = document.getElementById('qr-canvas');
  if (!canvas) return;
  const a = document.createElement('a');
  a.download = `QR_${_qrAssetId||'asset'}.png`;
  a.href = canvas.toDataURL('image/png');
  a.click();
  toast('QR code downloaded');
}

// ── INSPECTION ALERTS (dashboard) ─────────────────────────────────────────────
async function renderInspectionAlerts() {
  const panel = document.getElementById('inspection-alerts-panel');
  if (!panel) return;

  const today = new Date(); today.setHours(0,0,0,0);
  const soon  = new Date(today); soon.setDate(soon.getDate() + 7);

  let allAssets = assets;
  try { const r = await apiGetAssets({ limit:500 }); allAssets = r.assets || assets; } catch {}

  const alertAssets = allAssets.filter(a => {
    if (!a.nextInspection) return false;
    const d = new Date(a.nextInspection); d.setHours(0,0,0,0);
    return d <= soon;
  }).sort((a,b) => new Date(a.nextInspection) - new Date(b.nextInspection));

  if (!alertAssets.length) { panel.style.display='none'; return; }
  panel.style.display = 'block';

  const overdue = alertAssets.filter(a => new Date(a.nextInspection) < today).length;
  const countEl = document.getElementById('inspection-alert-count');
  if (countEl) countEl.textContent = `${overdue} overdue · ${alertAssets.length - overdue} due within 7 days`;

  const tbody = document.getElementById('inspection-alerts-tbody');
  if (tbody) tbody.innerHTML = alertAssets.map(a => {
    const d = new Date(a.nextInspection); d.setHours(0,0,0,0);
    const daysLeft = Math.round((d - today) / 86400000);
    const isOverdue = daysLeft < 0;
    return `<tr style="${isOverdue?'background:rgba(224,85,85,.04)':''}">
      <td><strong>${escHtml(a.name||a.assetId||a.id)}</strong></td>
      <td><span class="tag ${typeColor(a.type)}">${escHtml(a.type||'—')}</span></td>
      <td style="font-family:'Space Mono',monospace;font-size:11px">${escHtml(a.nextInspection)}</td>
      <td><span class="tag ${isOverdue?'tag-red':'tag-warn'}">${isOverdue?`<i class="fa-solid fa-circle-xmark"></i> OVERDUE ${Math.abs(daysLeft)}d`:`<i class="fa-solid fa-clock"></i> ${daysLeft}d`}</span></td>
      <td><button class="btn btn-primary btn-sm" onclick="showAssetDetail(${JSON.stringify(a).replace(/'/g,'&#39;')})"><i class="fa-solid fa-pen"></i> Action</button></td>
    </tr>`;
  }).join('');
}
