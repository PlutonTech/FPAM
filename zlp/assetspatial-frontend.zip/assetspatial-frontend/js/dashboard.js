// ── DASHBOARD ────────────────────────────────────────────────────────────────
async function renderDashboard() {
  try {
    const data = await apiDashboard();
    const s = data.summary || {};
    document.getElementById('stat-total').textContent    = s.total    || 0;
    document.getElementById('stat-active').textContent   = s.active   || 0;
    document.getElementById('stat-critical').textContent = s.critical || 0;
    document.getElementById('stat-value').textContent    = s.totalValueNGN
      ? '₦' + (s.totalValueNGN / 1e9).toFixed(1) + 'B' : '—';

    renderDashboardRecent(await apiGetAssets({ limit: 5 }).then(r => r.assets || []));
    renderActivityFeed();

    document.getElementById('nb-assets').textContent  = s.total || 0;
    document.getElementById('nb-assets2').textContent = s.total || 0;
  } catch {
    // Offline fallback
    document.getElementById('stat-total').textContent    = assets.length;
    document.getElementById('stat-active').textContent   = assets.filter(a=>a.status !== 'Decommissioned').length;
    document.getElementById('stat-critical').textContent = assets.filter(a=>a.condition === 'Critical').length;
    document.getElementById('stat-value').textContent    = '—';
    document.getElementById('nb-assets').textContent     = assets.length;
    document.getElementById('nb-assets2').textContent    = assets.length;
    document.getElementById('nb-users').textContent      = users.length;
    renderDashboardRecent([...assets].sort((a,b)=>b.ts-a.ts).slice(0,5));
    renderActivityFeed();
  }
}

function renderDashboardRecent(list) {
  const tbody = document.getElementById('recent-tbody');
  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="5"><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-layer-group"></i></div><div class="empty-title">No assets yet</div><div class="empty-sub">Capture your first asset</div></div></td></tr>`;
    return;
  }
  tbody.innerHTML = list.map(a => `
    <tr onclick="showAssetDetail(${JSON.stringify(a).replace(/"/g,'&quot;')})" style="cursor:pointer">
      <td>${escHtml(a.name || a.assetId || a.id)}</td>
      <td><span class="tag ${typeColor(a.type)}">${escHtml(a.type)}</span></td>
      <td>${geomIcon(a.geomType || a.geom)} ${escHtml(a.geomType || a.geom || '—')}</td>
      <td><span class="tag ${condColor(a.condition)}">${escHtml(a.condition)}</span></td>
      <td style="font-family:'Space Mono',monospace;font-size:10px;color:var(--text3)">${timeAgo(a.ts || new Date(a.createdAt).getTime())}</td>
    </tr>`).join('');
}

function renderActivityFeed() {
  const feed = document.getElementById('activity-feed');
  const entries = [...auditLog].slice(0, 6);
  if (!entries.length) {
    feed.innerHTML = `<div class="activity-item"><div class="activity-text" style="color:var(--text3)">No activity recorded yet.</div></div>`;
    return;
  }
  feed.innerHTML = entries.map((l, i) => `
    <div class="activity-item ${i<2?'new':''}">
      <div class="activity-text">${escHtml(l.action.replace(/_/g,' '))}: <strong>${escHtml(l.entity || l.entityId)}</strong> — ${escHtml(l.detail)}</div>
      <div class="activity-time">${new Date(l.ts).toLocaleString()} · ${escHtml(l.user || l.performedBy)}</div>
    </div>`).join('');
}
